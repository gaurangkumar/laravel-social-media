<?php
/**
 * The Front Controller for handling every request.
 *
 * @auther        GaurangKumar Parmar <gaurangkumarp@gmail.com>
 */
$root = false;

require 'public'.DIRECTORY_SEPARATOR.'index.php';
