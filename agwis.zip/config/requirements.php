<?php
/**
 * @auther        GaurangKumar Parmar <gaurangkumarp@gmail.com>
 */

/**
 * You can empty out this file, if you are certain that you match all requirements.
 *
 * You can remove this if you are confident that your PHP version is sufficient.
 */
if (version_compare(PHP_VERSION, '5.5.0') < 0) {
    trigger_error('Your PHP version must be equal or higher than 5.5.0 to use CakePHP.'.PHP_EOL, E_USER_ERROR);
}
